<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\PersonajeController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});


Route::controller(PersonajeController::class)->group(function (){
    Route::get('/Personajes', 'index');
    Route::post('/Personaje', 'store');
    Route::get('/Personaje/{id}', 'show');
    Route::put('/Personaje/{id}', 'update');
    Route::delete('/Personaje/{id}', 'destroy');
});
